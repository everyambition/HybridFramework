package com.inetBankingV2_BugFixing.utilities;



import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.WebDriver;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.inetBankingV2_BugFixing.testCases.BaseClass;

public class Listeners extends TestListenerAdapter {
    private ExtentReports extent;
    private ExtentTest test;
    public WebDriver driver;
   public String Path;

    @Override
    public void onStart(ITestContext testContext) {
        // Set the path of the report folder
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        String reportName = "Test-Report-" + timeStamp + ".html";
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "/test-output/" + reportName);

        // Set the configuration of the report
        htmlReporter.loadXMLConfig(System.getProperty("user.dir") + "/extent-config.xml");
        htmlReporter.config().setDocumentTitle("Sample Test Report");
        htmlReporter.config().setReportName("Test Automation Report");
        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
        htmlReporter.config().setTheme(Theme.DARK);

        // Create the ExtentReports and attach the reporter
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        // Set the system information
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("Tester", "Pravin");
        
    }

    @Override
    public void onFinish(ITestContext testContext) {
        // Flush the report and close the ExtentReports
        extent.flush();
       
    }

    @Override
    public void onTestStart(ITestResult result) {
        // Create a new test and set the test name
        test = extent.createTest(result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        // Log the test as passed
        test.log(Status.PASS, MarkupHelper.createLabel(result.getMethod().getMethodName() + " test case PASSED", ExtentColor.GREEN));
    }

    @Override
    public void onTestFailure(ITestResult result) 
    {
    	try {
			 Path=BaseClass.captureScreen(result.getName());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
        // Log the test as failed and attach the screenshot
        test.log(Status.FAIL, MarkupHelper.createLabel(result.getMethod().getMethodName() + " test case FAILED due to below issues:", ExtentColor.RED));
        test.fail(result.getThrowable());
        
        try {
            
            String screenshotPath = Path;  
        	test.addScreenCaptureFromPath(screenshotPath);
        	
        } catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
    
    

    @Override
    public void onTestSkipped(ITestResult result) {
        // Log the test as skipped
        test.log(Status.SKIP, MarkupHelper.createLabel(result.getMethod().getMethodName() + " test case SKIPPED", ExtentColor.ORANGE));
    }
    
}