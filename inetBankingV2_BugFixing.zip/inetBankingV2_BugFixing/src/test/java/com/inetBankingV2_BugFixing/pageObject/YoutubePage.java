package com.inetBankingV2_BugFixing.pageObject;

public class YoutubePage {

}
